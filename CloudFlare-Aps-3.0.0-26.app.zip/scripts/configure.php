<?
define("CF_HOST_API_ENDPOINT",     "https://api.cloudflare.com/host-gw.html");
define("CF_USER_API_ENDPOINT",     "https://www.cloudflare.com/api_json.html");
define("CF_HOST_PREFIX",           "cloudflare-resolve-to");
define("CF_HOST_ID_PREFIX",        "plesk_");
define("DEBUG_LEVEL",              0);
define("CF_VERSION",               "0.1");
define ('PLESK_ADMIN_URL',         'https://' . getenv("BASE_URL_HOST") . ':8443/enterprise/control/agent.php'); // Assume this is the right place...
define ('PLESK_ADMIN_USER',        getenv("SETTINGS_admin_login"));
define ('PLESK_ADMIN_PASS',        getenv("SETTINGS_admin_password"));
define ('CF_API_SALT',             PLESK_ADMIN_USER . '9-y743fasd843983h498aasedfdf988aaq098dasf0932u023409pj' . PLESK_ADMIN_PASS);

$handler = new CloudFlareHandler();

// BEGIN API KEY AUTOGEN
if (!file_exists(getenv("WEB___DIR")."/cf-admin/apikey.php")) {
    $kf = @fopen(getenv("WEB___DIR")."/cf-admin/apikey.php", "w");
    fputs($kf, "<?php ?>");
    fclose($kf);
}

$file_contents = file_get_contents(getenv("WEB___DIR")."/cf-admin/apikey.php");

if (trim($file_contents) == '<?php ?>')
{
    if (getenv("SETTINGS_host_email")!='')
    {
        $params3 = array();
        $params3["host_key"]  = "plesk";
        $params3["host_name"] = getenv("SETTINGS_host_name");
        $params3["email"] = getenv("SETTINGS_host_email");
        $params3["pub_name"]  = getenv("SETTINGS_host_name");
        $params3["prefix"]    = "plesk_";
        $params3["website"]   = getenv("SETTINGS_host_website");
        $params3["act"]       = "host_child_plesk_new";

        $response3            = $handler->performRequest($params3);

        if ($response3 !== FALSE)
        {
            $res3 = json_decode($response3, TRUE);

            if ($res3["result"] == "success")
            {
                $host_key = $res3["request"]["host_info"]["__api_key"];
                $xorCrypt = new xorCrypt();
                $xorCrypt->set_key(CF_API_SALT);
                $host_key = $xorCrypt->encrypt($host_key);

                $kf = @fopen(getenv("WEB___DIR")."/cf-admin/apikey.php", "w");
                fputs($kf, "<?php\n");
                fputs($kf, "define('CF_HOST_KEY','" . $host_key ."');\n");
                fputs($kf, "?>");
                fclose($kf);
            }
        }
    }
}
// END API KEY AUTOGEN

include_once(getenv("WEB___DIR")."/cf-admin/apikey.php");

class CloudFlareHandler {

    var $run;
    var $cf_user_id;
    var $dom_id;
    var $cf_user_email;
    var $user_name;
    var $user_key;
    var $user_api_key;
    var $error;
    var $result;
    var $guid;
    var $stop_on_empty;
    var $xorCrypt;

    function CloudFlareHandler() {

        $this->xorCrypt = new xorCrypt();
        $this->xorCrypt->set_key(CF_API_SALT);
    }


    function getZoneSubdomains()
    {
            $subdomains = array();
            // Now get the internal version of what we have.
            $req   = '<packet version="1.6.3.0"><dns><get_rec><filter><site-id>' . $_REQUEST["dom_id"] . '</site-id></filter></get_rec></dns></packet>';
            $ir    = $this->performInternalRequest($req);
            $recs  = array();
            $zones = array();

            if ($ir) {
                $xml = new SimpleXMLElement($ir);
                if ($xml) {
                    foreach ($xml->dns->get_rec->result as $rec){

                        if (($rec->data->type == "A" || $rec->data->type == "CNAME")
                            && (!preg_match('/(^direct|^ssh|^ftp|^ssl|^ns[^.]*|^imap[^.]*|^pop[^.]*|smtp[^.]*|^mail[^.]*|^mx[^.]*|^exchange[^.]*|^smtp[^.]*|google[^.]*|^secure|^sftp|^svn|^git|^irc|^email|^mobilemail|^pda|^webmail|^\*\.webmail|^e\.|^video|^vid|^vids|^sites|^calendar|^svn|^cvs|^git|^cpanel|^panel|^repo|^webstats|^local|localhost|^'.CF_HOST_PREFIX.')/', (string)$rec->data->host))
                            && (!preg_match('/google.com/', (string)$rec->data->value))) {
                            $recs[] = array("name"    => substr($rec->data->host, -1) == "." ? substr($rec->data->host, 0, -1) : $rec->data->host,
                                            "content" => substr($rec->data->value, -1) == "." ? substr($rec->data->value, 0, -1) : $rec->data->value,
                                            "rec_id"  => (int)$rec->id,
                                            "type"    => (string)$rec->data->type,
                                            "on_cf"   => preg_match('/cdn.cloudflare.net.$/', (string)$rec->data->value));
                        }
                    }

                    return array("error" => FALSE, "msg"=> "NOOP", "recs" => $recs, "zones" => array($_REQUEST["zone_name"]), "cf" => "1");
                }
            }
            return array("error" => TRUE, "msg"=> $ir);
    }

    function getZoneSubdomainResolveTos()
    {
            $subdomains = array();
            // Now get the internal version of what we have.
            $req   = '<packet version="1.6.3.0"><dns><get_rec><filter><site-id>' . $_REQUEST["dom_id"] . '</site-id></filter></get_rec></dns></packet>';
            $ir    = $this->performInternalRequest($req);
            $recs  = array();
            $zones = array();

            if ($ir) {
                $xml = new SimpleXMLElement($ir);
                if ($xml) {
                    foreach ($xml->dns->get_rec->result as $rec) {
                        if (($rec->data->type == "A" || $rec->data->type == "CNAME") && (preg_match('/('.CF_HOST_PREFIX.')/', (string)$rec->data->host))) {
                            $recs[] = array("name"    => substr($rec->data->host, -1) == "." ? substr($rec->data->host, 0, -1) : $rec->data->host,
                                            "content" => substr($rec->data->value, -1) == "." ? substr($rec->data->value, 0, -1) : $rec->data->value,
                                            "rec_id"  => (int)$rec->id,
                                            "type"    => (string)$rec->data->type,
                                            "on_cf"   => preg_match('/cdn.cloudflare.net.$/', (string)$rec->data->value));
                        }
                    }

                    return array("error" => FALSE, "msg"=> "NOOP", "recs" => $recs, "zones" => array($_REQUEST["zone_name"]), "cf" => "1");
                }
            }
            return array("error" => TRUE, "msg"=> $ir);
    }

    // Determine if the related DNS record has a related resolve-to record.
    // If so, remove the resolve-to record and restore the original DNS record prior to enabling it on CloudFlare.
    function removeResolveTosAndRevertDNSRecord($dnsRecord, $subdomain, $resolveTos) {
        foreach($resolveTos["recs"] as $rec)
        {
            if ($rec["name"] == CF_HOST_PREFIX.".".$dnsRecord["name"])
            {
                // Delete the existing DNS record pointing to CloudFlare.
                $req = $this->createDeleteXMLRequest(array("0"=>$dnsRecord["rec_id"]));
                $result = $this->performInternalRequest($req);

                // Revert back to the original DNS record.
                $req = $this->createAddXMLRequestByType(array($subdomain => $rec["content"]), $rec["type"]);
                $result  = $this->performInternalRequest($req);

                // Delete the custom resolve-to record.
                $req = $this->createDeleteXMLRequest(array("0"=>$rec["rec_id"]));
                $result = $this->performInternalRequest($req);

                return TRUE;
            }
        }

        return FALSE;
    }

    function revertDNSRecord($dnsRecord, $subdomain) {
        $req = $this->createDeleteXMLRequest(array("0"=>$dnsRecord["rec_id"]));
        $result = $this->performInternalRequest($req);

        // Create the resolve to DNS record for the record.
        $req = $this->createAddXMLRequestByType(array($subdomain => $_REQUEST["zone_name"]), $dnsRecord["type"]);
        $result  = $this->performInternalRequest($req);
    }


    function user_create($pass = NULL) {

        include_once(getenv("WEB___DIR")."/cf-admin/apikey.php");

        $params                         = array();
        $params["host_key"]             = $this->xorCrypt->decrypt(CF_HOST_KEY);
        $params["cloudflare_email"]     = $this->cf_user_email;
        $params["cloudflare_pass"]      = ($pass)? $pass: md5(time() . $this->cf_user_email . "sdjkfh2386548376");
        $params["cloudflare_username"]  = $this->user_name;
        $params["unique_id"]            = $this->cf_user_id;
        $params["act"]                  = "user_create";
        $response                       = $this->performRequest($params);

        if ($response === FALSE) {
            return array("error" => TRUE, "msg"=> "Failed to get response from service.");
        } else {
            $res                = json_decode($response, TRUE);
            if (!array_key_exists("result", $res)) {
                $this->user_key     = $res["response"]["user_key"];
                $this->user_api_key = $res["response"]["user_api_key"];
            }
            return $res;
        }
    }

    function check_version() {

        $params                         = array();
        $params["host_key"]             = $this->xorCrypt->decrypt(CF_HOST_KEY);
        $params["act"]                  = "cpanel_info";
        $response                       = $this->performRequest($params);

        if ($response === FALSE) {
            return array("error" => TRUE, "msg"=> "Failed to get response from service.");
        } else {
            $res                = json_decode($response, TRUE);
            return $res;
        }
    }

    function processZoneUnSub() {

        $params                         = array();
        $params["host_key"]             = $this->xorCrypt->decrypt(CF_HOST_KEY);
        $params["user_key"]             = $this->user_key;
        $params["zone_name"]            = $_REQUEST["zone_name"];
        $params["plan_tag"]             = $_REQUEST["plan_tag"];
        $params["sub_id"]               = $_REQUEST["sub_id"];
        $params["act"]                  = "reseller_sub_cancel";
        $response                       = $this->performRequest($params);

        if ($response === FALSE) {
            $this->result = array("error" => TRUE, "msg"=> "Failed to get response from service.");
            return FALSE;
        } else {
            $this->result = json_decode($response, TRUE);
            return TRUE;
        }
    }

    function processZoneSub() {

        $params                         = array();
        $params["host_key"]             = $this->xorCrypt->decrypt(CF_HOST_KEY);
        $params["user_key"]             = $this->user_key;
        $params["zone_name"]            = $_REQUEST["zone_name"];
        $params["plan_tag"]             = "PSA_KEY";
        $params["psa_key"]              = $_REQUEST["psa_key"];
        $params["act"]                  = "reseller_sub_new";
        $response                       = $this->performRequest($params);

        if ($response === FALSE) {
            $this->result = array("error" => TRUE, "msg"=> "Failed to get response from service.");
            return FALSE;
        } else {
            $this->result = json_decode($response, TRUE);
            return TRUE;
        }
    }

    function user_auth($pass) {

        $params                         = array();
        $params["host_key"]             = $this->xorCrypt->decrypt(CF_HOST_KEY);
        $params["cloudflare_email"]     = $this->cf_user_email;
        $params["cloudflare_pass"]      = $pass;
        $params["act"]                  = "user_auth";
        $response                       = $this->performRequest($params);

        if ($response === FALSE) {
            return array("error" => TRUE, "msg"=> "Failed to get response from service.");
        } else {
            $res                = json_decode($response, TRUE);
            if (!array_key_exists("result", $res)) {
                $this->user_key     = $res["response"]["user_key"];
                $this->user_api_key = $res["response"]["user_api_key"];
            }
            return $res;
        }
    }

    function createAddXMLRequest($recs) {
        $data = '<packet version="1.6.3.0"><dns>';
        foreach ($recs as $name => $content) {
            $data .= '<add_rec><site-id>' . $this->dom_id . '</site-id><type>CNAME</type><host>' . $name . '</host><value>' . $content . '</value></add_rec>';
        }
        $data .= '</dns></packet>';
        return $data;
    }

    function createAddXMLRequestByType($recs, $type="CNAME") {
        $data = '<packet version="1.6.3.0"><dns>';
        foreach ($recs as $name => $content) {
            $data .= '<add_rec><site-id>' . $this->dom_id . '</site-id><type>'.$type.'</type><host>' . $name . '</host><value>' . $content . '</value></add_rec>';
        }
        $data .= '</dns></packet>';
        return $data;
    }

    function createDeleteXMLRequest($recs) {
        $data='<packet version="1.4.2.0"><dns><del_rec><filter>';
        foreach ($recs as $id) {
            $data .= '<id>' . $id . '</id>';
        }
        $data .= '</filter></del_rec></dns></packet>';
        return $data;
    }

    function createDomainIdXMLRequest($domain) {
        $packet = '<packet version="1.6.3.0"><site><get><filter><name>'.$domain.'</name></filter><dataset><gen_info/></dataset></get></site></packet>';
        return $packet;
    }

    public function get_domain_id($zone_name) {
        $req          = $this->createDomainIdXMLRequest($zone_name);
        $ir           = $this->performInternalRequest($req);
        $domain_id    = 0;

        if ($ir) {
            $xml = new SimpleXMLElement($ir);
            if ($xml) {
                $domain_id = (string)($xml->site->get->result->id);
            }
        }

        return $domain_id;
    }

    function zone_set($zone_name, &$subdomains) {
        if (!$this->user_key) {
            return array("error" => TRUE, "msg"=> "Missing User Key");
        }

        $params                         = array();
        $params["host_key"]             = $this->xorCrypt->decrypt(CF_HOST_KEY);
        $params["user_key"]             = $this->user_key;
        $params["zone_name"]            = $zone_name;
        $params["resolve_to"]           = CF_HOST_PREFIX . "." . $zone_name;
        $params["act"]                  = "zone_set";
        $params["subdomains"]           = implode(",", $subdomains);
        $response                       = $this->performRequest($params);

        if ($response === FALSE) {
            return array("error" => TRUE, "msg"=> "Failed to get response from service.");
        } else {
            $res          = json_decode($response, TRUE);

            if (!$res || $res["result"] == 'error') {
                return array("error" => TRUE, "res" => $res, "msg" => $res["msg"]);
            }

            // Try adding the resolve_to listing
            $req          = $this->createAddXMLRequest(array(CF_HOST_PREFIX => $zone_name));
            $ir           = $this->performInternalRequest($req);

            return array("error" => FALSE, "res" => $res);
        }
    }

    function user_lookup() {

        $lookup_type                    = ($this->cf_user_id)? "unique_id": "cloudflare_email";
        $lookup_value                   = ($this->cf_user_id)? $this->cf_user_id: $this->cf_user_email;
        $params                         = array();
        $params[$lookup_type]           = $lookup_value;
        $params["host_key"]             = $this->xorCrypt->decrypt(CF_HOST_KEY);
        $params["act"]                  = "user_lookup";
        $response                       = $this->performRequest($params);

        if ($response === FALSE) {
            return array("error" => TRUE, "msg"=> "Failed to get response from service.");
        } else {
            $res = json_decode($response, TRUE);
            if (is_array($res) && array_key_exists("response", $res) && $res["response"]["user_exists"]) {
                $this->user_key = $res["response"]["user_key"];
                $this->user_api_key = $res["response"]["user_api_key"];
                return $res;
            }
            $this->error = $res["msg"];
            return FALSE;
        }
    }

    function zone_lookup($zone_name) {

        $params                         = array();
        $params["host_key"]             = $this->xorCrypt->decrypt(CF_HOST_KEY);
        $params["act"]                  = "zone_list";
        $params["zone_name"]            = $zone_name;
        $response                       = $this->performRequest($params);
        $cf_list                        = NULL;

        if ($response === FALSE) {
            return array("error" => TRUE, "msg"=> "Failed to get list response from service.");
        } else {
            $cf_list = json_decode($response, TRUE);
        }

        // Now get the internal version of what we have.
        $req   = '<packet version="1.6.3.0"><dns><get_rec><filter><site-id>' . $this->dom_id . '</site-id></filter></get_rec></dns></packet>';
        $ir    = $this->performInternalRequest($req);
        $recs  = array();
        $zones = array();
        $xml;

        if ($ir) {
            $xml = new SimpleXMLElement($ir);
            if ($xml) {
                foreach ($xml->dns->get_rec->result as $rec){

                    if ($rec->data->type == "CNAME"
                        && (!preg_match('/(^direct|^ssh|^ftp|^ssl|^ns[^.]*|^imap[^.]*|^pop[^.]*|smtp[^.]*|^mail[^.]*|^mx[^.]*|^exchange[^.]*|^smtp[^.]*|google[^.]*|^secure|^sftp|^svn|^git|^irc|^email|^mobilemail|^pda|^webmail|^\*\.webmail|^e\.|^video|^vid|^vids|^sites|^calendar|^svn|^cvs|^git|^cpanel|^panel|^repo|^webstats|^local|localhost|^'.CF_HOST_PREFIX.')/', (string)$rec->data->host))
                        && (!preg_match('/google.com/', (string)$rec->data->value))) {
                        $recs[] = array("name"    => preg_replace("#.$#", "", (string)$rec->data->host),
                                        "content" => preg_replace("#.$#", "", (string)$rec->data->value),
                                        "rec_id"  => (int)$rec->id,
                                        "type"    => (string)$rec->data->type,
                                        "on_cf"   => preg_match('/cdn.cloudflare.net.$/', (string)$rec->data->value));
                    }
                }

                return array("error" => FALSE, "msg"=> "NOOP", "recs" => $recs, "zones" => array($zone_name), "cf" => $cf_list["response"]);
            }
        }
        return array("error" => TRUE, "msg"=> $ir);
    }

    function zone_delete($zone_name) {
        if (!$this->user_key) {
            return array("error" => TRUE, "msg"=> "Missing User Key");
        }

        $params                         = array();
        $params["host_key"]             = $this->xorCrypt->decrypt(CF_HOST_KEY);
        $params["user_key"]             = $this->user_key;
        $params["zone_name"]            = $zone_name;
        $params["act"]                  = "zone_delete";
        $response                       = json_decode($this->performRequest($params), TRUE);

        if ($response === FALSE) {
            return array("error" => TRUE, "msg"=> "Failed to get response from service.");
        } else {
            if ($response["result"] == "success") {
                // deprecated
            }
            return array("error" => FALSE, "res" => $response);
        }
    }

    function performRequest(& $data, $headers=NULL) {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, CF_HOST_API_ENDPOINT);

        if (DEBUG_LEVEL > 1) {
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
        }
        if (DEBUG_LEVEL > 0) {
            echo "REQUEST DATA (to be sent via POST):\n";
            print_r($data);
        }

        if ($headers) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        }
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        if ($data) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        }

        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        //curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_AUTOREFERER,    TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

        if (($http_result = curl_exec($ch)) === FALSE) {
            echo "WARNING: A connectivity error occured while contacting the service.\n";
            trigger_error(curl_error($ch));
            return FALSE;
        }

        curl_close($ch);

        if (DEBUG_LEVEL > 0) {
            print_r(json_decode($http_result, TRUE));
        }

        return $http_result;
    }

 function performInternalRequest(& $data) {

        $ch = curl_init();

        $headers = array(
                         'HTTP_AUTH_LOGIN: ' . PLESK_ADMIN_USER,
                         'HTTP_AUTH_PASSWD: ' . PLESK_ADMIN_PASS,
                         'Content-Type: text/xml'
                         );

        curl_setopt($ch, CURLOPT_URL,              PLESK_ADMIN_URL);
        curl_setopt($ch, CURLOPT_HTTPHEADER,       $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,   0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,   FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,   TRUE);

        if ($data) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        } else {
            return FALSE;
        }

        if (DEBUG_LEVEL > 1) {
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
        }
        if (DEBUG_LEVEL > 0) {
            echo "REQUEST DATA (to be sent via POST):\n";
            print_r($data);
        }
        curl_setopt($ch, CURLOPT_TIMEOUT,          30);
        curl_setopt($ch, CURLOPT_AUTOREFERER,      TRUE);

        if (($http_result = curl_exec($ch)) === FALSE) {
            echo "WARNING: A connectivity error occured while contacting the service.\n";
            trigger_error(curl_error($ch));
            return FALSE;
        }

        curl_close($ch);
        return $http_result;
    }

    function reportErr($key, $value) {
        $this->error = array("error" => TRUE, "msg" => $value, "key" => $key);
    }

    function validate() {
        if (!preg_match('/^(reseller_sub_new|reseller_sub_cancel|user_auth|user_create|user_lookup|zone_lookup|zone_set|zone_delete)$/i',$_REQUEST["act"])) {
            $this->reportErr("bad_act","Invalid act: " . $_REQUEST["act"]);
            return FALSE;
        }
        return TRUE;
    }

    function processUserCreate() {
        $password     = $_REQUEST["user_pass"];
        $this->result = $this->user_create($password);
    }

    function processUserAuth() {
        $password     = $_REQUEST["user_pass"];
        $this->result = $this->user_auth($password);
    }

    function processUserLookup() {
        $this->result = $this->user_lookup();
    }

    function processZoneLookup() {
        $domain_name  = $_REQUEST["domain_name"];
        $this->result = $this->zone_lookup($domain_name);
    }

    function processZoneSet() {
        $zone_name = $_REQUEST["zone_name"];
	    $cnames =  $_REQUEST["subList"];

        if ($zone_name && $cnames) {
            if (!$this->user_key) {
                $this->user_lookup();
            }
            if (count($cnames)) {
                $this->result = $this->zone_set($zone_name, $cnames);
            } else {
                $this->result = $this->zone_delete($zone_name);
            }
        } else if ($zone_name) {
            // Try deleting the zone.
            $this->result = $this->zone_delete($zone_name);
        } else {
            $this->reportErr("inv", "Invalid zone_name or zone_info parameter.");
        }

        // OK, now get a list of the new zone info.
        $this->result["lookup"] = $this->zone_lookup($zone_name);
    }

    function processZoneDelete() {
        $zone_name    = $_REQUEST["zone_name"];

        if ($zone_name) {
            if (!$this->user_key) {
                $this->user_lookup();
            }
            $this->result = $this->zone_delete($zone_name);
        }
    }

    function process() {

        $user_name           = $_REQUEST["user_name"];
        $this->cf_user_email = $_REQUEST["user_email"];
        $this->dom_id        = $_REQUEST["dom_id"];
        $this->cf_user_id    = CF_HOST_ID_PREFIX . $user_name;
        $this->user_name     = CF_HOST_ID_PREFIX . $user_name;
        $this->user_key      = (array_key_exists("user_key", $_REQUEST))? $_REQUEST["user_key"]: NULL;
        $this->user_api_key  = (array_key_exists("user_api_key", $_REQUEST))? $_REQUEST["user_api_key"]: NULL;

        if (!$this->validate()) {
            return FALSE;
        }

        if ($this->isZoneDelete()) {
            $this->processZoneDelete();
        } else if ($this->isZoneSet()) {
            $this->processZoneSet();
        } else if ($this->isUserCreate()) {
            $this->processUserCreate();
        } else if ($this->isUserLookup()) {
            $this->processUserLookup();
        } else if ($this->isZoneLookup()) {
            $this->processZoneLookup();
        } else if ($this->isUserAuth()) {
            $this->processUserAuth();
        } else if ($this->isZoneUnSub()) {
            $this->processZoneUnSub();
        } else if ($this->isZoneSub()) {
            $this->processZoneSub();
        }

        return TRUE;
    }

    function build_json() {
        if ($this->error) {
            return json_encode($this->error);
        } else {
            return json_encode($this->result);
        }
    }

    function build_memc() {
        if ($this->error) {
            return $this->error;
        } else {
            return $this->result;
        }
    }

    function getUserKey(){ return $this->user_key; }
    function getUserAPIKey(){ return $this->user_api_key; }

    function isZoneDelete(){ return $_REQUEST["act"] == "zone_delete"; }
    function isZoneSet(){ return $_REQUEST["act"] == "zone_set"; }
    function isZoneSub(){ return $_REQUEST["act"] == "reseller_sub_new"; }
    function isZoneUnSub(){ return $_REQUEST["act"] == "reseller_sub_cancel"; }
    function isUserCreate(){ return $_REQUEST["act"] == "user_create"; }
    function isUserLookup(){ return $_REQUEST["act"] == "user_lookup"; }
    function isZoneLookup(){ return $_REQUEST["act"] == "zone_lookup"; }
    function isUserAuth(){ return $_REQUEST["act"] == "user_auth"; }

    public function runOne(&$job_row, &$result) {

        if ($job_row && $job_row["id"]) {
            foreach ($job_row["request"] as $k => $v) {
                $_REQUEST[$k] = $v;
            }
            $this->process();
            $result = $this->build_memc();
            return TRUE;
        }
        return FALSE;
    }

    private function debug($level, $msg) {
        if (DEBUG_LEVEL > $level) {
            print($msg);
        }
    }
}

class xorCrypt {
	private $password = NULL;

	public function set_key($password) {
		$this->password = $password;
	}

	private function get_rnd_iv($iv_len) {
		$iv = '';
		while ($iv_len-- > 0) {
			$iv .= chr(mt_rand() & 0xff);
		}
		return $iv;
	}

	public function encrypt($plain_text, $iv_len = 16) {
		$plain_text .= "\x13";
		$n = strlen($plain_text);
		if ($n % 16) {
			$plain_text .= str_repeat("\0", 16 - ($n % 16));
			$i = 0;
			$enc_text = $this->get_rnd_iv($iv_len);
			$iv = substr($this->password ^ $enc_text, 0, 512);
			while ($i < $n) {
				$block = substr($plain_text, $i, 16) ^ pack('H*', sha1($iv));
				$enc_text .= $block;
				$iv = substr($block . $iv, 0, 512) ^ $this->password;
				$i += 16;
			}
			return base64_encode($enc_text);
		} else {}
	}

	public function decrypt($enc_text, $iv_len = 16) {
		$enc_text = base64_decode($enc_text);
		$n = strlen($enc_text);
		$i = $iv_len;
		$plain_text = '';
		$iv = substr($this->password ^ substr($enc_text, 0, $iv_len), 0, 512);
		while ($i < $n) {
			$block = substr($enc_text, $i, 16);
			$plain_text .= $block ^ pack('H*', sha1($iv));
			$iv = substr($block . $iv, 0, 512) ^ $this->password;
			$i += 16;
		}
		return stripslashes(preg_replace('/\\x13\\x00*$/', '', $plain_text));
	}
}

function main($handler) {

    global $errors;
    global $argv;

    $params["base_url"]         = getenv("BASE_URL_PATH");
    $params["zone_name"]        = getenv("BASE_URL_HOST");
    $params["domain_name"]      = getenv("BASE_URL_HOST");
    $params["cnames"]           = explode(",", getenv("SETTINGS_cnames"));
    $params["user_name"]        = getenv("SETTINGS_admin_username");
    $params["user_email"]       = getenv("SETTINGS_cf_email");
    $params["user_pass"]        = getenv("SETTINGS_cf_password");
    $params["dom_id"]           = (int)$handler->get_domain_id($params["zone_name"]);
    $params["act"]              = "user_create";
	$params["site_server_path"] = getenv("WEB___DIR");

    if (!$params["dom_id"]) {
        $errors[] = "Cannot find a valid domain id. Get your hosting provider to check the package settings.";
		return FALSE;
    }

    $id  = md5(time()."dsfsdkaavvjfh".rand());
    $job = array("id" => $id, "request" => $params);

    // Do user_create
    $result = array();
    $handler->runOne($job, $result);

    if ((array_key_exists("response", $result)) && $result["response"]["user_key"]) {
        $params["user_key"]     = $result["response"]["user_key"];
        $params["user_api_key"] = $result["response"]["user_api_key"];
    } else {
        $errors[] = $result["msg"];
		return FALSE;
    }

    $cf_enabled = getenv("SETTINGS_cf_enabled");

    // Get and prep the subdomains
    $subdomains = $handler->getZoneSubdomains();
    $subdomainsInclusionList = explode(",", getenv("SETTINGS_cf_sub_inclusion"));
    //$_REQUEST["subList"][0] = "www"; // Moved to default value for subdomain list upon installation of Cloudflare.
    $i = 1;
    foreach($subdomainsInclusionList as $sub) {
        $sub = trim($sub);
        if ($sub!='') {
            $_REQUEST["subList"][$i] = $sub;
            $i++;
        }
    }

    // Get resolve-tos.  This is used when subdomains are removed from subdomain inclusion list
    $resolveTos = $handler->getZoneSubdomainResolveTos();

    if (isset($cf_enabled) && $cf_enabled == "on") {
        if (isset($subdomains["recs"]) && count($subdomains["recs"]) > 0) {
            foreach($subdomains["recs"] as $val){
                $subdomain = str_replace("." . $_REQUEST["zone_name"], "", $val["name"]);
                if (!$val["on_cf"] && in_array($subdomain, $subdomainsInclusionList))
                {
                    // Delete the existing DNS record.
                    $req = $handler->createDeleteXMLRequest(array("0"=>$val["rec_id"]));
                    $result = $handler->performInternalRequest($req);

                    // Create a CNAME record pointing to CloudFlare
                    $req = $handler->createAddXMLRequestByType(array($subdomain => $val["name"].".cdn.cloudflare.net"), "CNAME");
                    $result  = $handler->performInternalRequest($req);

                    // Add the DNS resolve to record for the cases where the A or CNAME record was originally pointing to a third party source.
                    if ($val["content"] != $_REQUEST["zone_name"]) {
                        $key = array_search($subdomain, $_REQUEST["subList"]);
                        $_REQUEST["subList"][$key] = $subdomain.":".CF_HOST_PREFIX.".".$subdomain . ".".$_REQUEST["zone_name"];

                        // Create the resolve-to DNS record for the record.
                        $req = $handler->createAddXMLRequestByType(array(CF_HOST_PREFIX.".".$subdomain => $val["content"]), $val["type"]);
                        $result  = $handler->performInternalRequest($req);
                    }

                } elseif ($val["on_cf"] && !in_array($subdomain, $subdomainsInclusionList)) {
                    // If the record didnt find a match with a resolve to, we still need to delete the cf enabled record
                    // and replace it with the non-cf "content" value (ie. the domain name).
                    if (!$handler->removeResolveTosAndRevertDNSRecord($val, $subdomain, $resolveTos)) {
                        $handler->revertDNSRecord($val, $subdomain);
                    }
                }
            }
        }

        $handler->processZoneSet();
    } else {
        if (isset($subdomains["recs"]) && count($subdomains["recs"]) > 0) {
            foreach($subdomains["recs"] as $val){
                $subdomain = str_replace("." . $_REQUEST["zone_name"], "", $val["name"]);
                if (in_array($subdomain, $subdomainsInclusionList))
                {
                    // If the record didnt find a match with a resolve to, we still need to delete the cf enabled record
                    // and replace it with the non-cf "content" value (ie. the domain name).
                    if (!$handler->removeResolveTosAndRevertDNSRecord($val, $subdomain, $resolveTos) && $val["on_cf"]) {
                        $handler->revertDNSRecord($val, $subdomain);
                    }
                }
            }
        }

        $handler->processZoneDelete();
    }

    $command = $argv[1];

	switch($command)
	{
        case "remove" :
            // Do same processes as if CloudFlare enabled was set to "Off"
            if (isset($subdomains["recs"]) && count($subdomains["recs"]) > 0) {
                foreach($subdomains["recs"] as $val){
                    $subdomain = str_replace("." . $_REQUEST["zone_name"], "", $val["name"]);
                    if (in_array($subdomain, $subdomainsInclusionList))
                    {
                        // If the record didnt find a match with a resolve to, we still need to delete the cf enabled record
                        // and replace it with the non-cf "content" value (ie. the domain name).
                        if (!$handler->removeResolveTosAndRevertDNSRecord($val, $subdomain, $resolveTos) && $val["on_cf"]) {
                            $handler->revertDNSRecord($val, $subdomain);
                        }
                    }
                }
            }

            $handler->processZoneDelete();
        break;
        case "install":break;
        case "upgrade":break;
        case "configure":break;
        default:break;
	}

    // And we are good.
    return TRUE;
}

$handler = new CloudFlareHandler();
$res = main($handler);

if (count($errors)) {
  $res = "<p>Error Encountered:</p><p><ul>";
  foreach ($errors as $e) { $res .= ("<li>$e</li>"); }
  $res .= "</ul></p>";

  print($res);
  exit(10);
}

?>