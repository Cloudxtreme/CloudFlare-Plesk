<?php 

class xorCrypt {
	private $password = NULL;

	public function set_key($password) {
		$this->password = $password;
	}

	private function get_rnd_iv($iv_len) {
		$iv = '';
		while ($iv_len-- > 0) {
			$iv .= chr(mt_rand() & 0xff);
		}
		return $iv;
	}

	public function encrypt($plain_text, $iv_len = 16) {
		$plain_text .= "\x13";
		$n = strlen($plain_text);
		if ($n % 16) {
			$plain_text .= str_repeat("\0", 16 - ($n % 16));
			$i = 0;
			$enc_text = $this->get_rnd_iv($iv_len);
			$iv = substr($this->password ^ $enc_text, 0, 512);
			while ($i < $n) {
				$block = substr($plain_text, $i, 16) ^ pack('H*', sha1($iv));
				$enc_text .= $block;
				$iv = substr($block . $iv, 0, 512) ^ $this->password;
				$i += 16;
			}
			return base64_encode($enc_text);
		} else {}
	}

	public function decrypt($enc_text, $iv_len = 16) {
		$enc_text = base64_decode($enc_text);
		$n = strlen($enc_text);
		$i = $iv_len;
		$plain_text = '';
		$iv = substr($this->password ^ substr($enc_text, 0, $iv_len), 0, 512);
		while ($i < $n) {
			$block = substr($enc_text, $i, 16);
			$plain_text .= $block ^ pack('H*', sha1($iv));
			$iv = substr($block . $iv, 0, 512) ^ $this->password;
			$i += 16;
		}
		return stripslashes(preg_replace('/\\x13\\x00*$/', '', $plain_text));
	}
}

function performRequest(& $data, $headers=NULL) {

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, CF_HOST_API_ENDPOINT);

    if (DEBUG_LEVEL > 1) {
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
    }
    if (DEBUG_LEVEL > 0) {
        echo "REQUEST DATA (to be sent via POST):\n";
        print_r($data);
    }

    if ($headers) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    if ($data) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }

    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    //curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_AUTOREFERER,    TRUE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

    if (($http_result = curl_exec($ch)) === FALSE) {
        echo "WARNING: A connectivity error occured while contacting the service.\n";
        trigger_error(curl_error($ch));
        return FALSE;
    }

    curl_close($ch);

    if (DEBUG_LEVEL > 0) {
        print_r(json_decode($http_result, TRUE));
    }

    return $http_result;
}

function user_lookup($email, $host_api_key) {
    $params                         = array();
    $params["cloudflare_email"]     = $email;
    $params["host_key"]             = $host_api_key;
    $params["act"]                  = "user_lookup";
    $response                       = performRequest($params);

    if ($response === FALSE) {
        return array("error" => TRUE, "msg"=> "Failed to get response from service.");
    } else {
        $res = json_decode($response, TRUE);
        if (is_array($res) && array_key_exists("response", $res) && $res["response"]["user_exists"]) {
            return $res;
        }

        return FALSE;
    }
}

function processZoneSub($zone_name, $host_api_key, $user_key, $psa_key) {
    $params                         = array();
    $params["host_key"]             = $host_api_key;
    $params["user_key"]             = $user_key;
    $params["zone_name"]            = $zone_name;
    $params["plan_tag"]             = "PSA_KEY";
    $params["psa_key"]              = $psa_key;
    $params["act"]                  = "reseller_sub_new";
    $response                       = performRequest($params);

    if ($response === FALSE) {
        return array("error" => TRUE, "msg"=> "Failed to get response from service.");
    } else {
        return json_decode($response, TRUE);
    }
}

define("CF_HOST_API_ENDPOINT",     "https://api.cloudflare.com/host-gw.html");
define("CF_USER_API_ENDPOINT",     "https://www.cloudflare.com/api_json.html");
define("CF_HOST_PREFIX",           "cloudflare-resolve-to");
define("CF_HOST_ID_PREFIX",        "plesk_");
define("DEBUG_LEVEL",              0);
define("CF_VERSION",               "0.1");
define ('PLESK_ADMIN_URL',         'https://' . getenv("BASE_URL_HOST") . ':8443/enterprise/control/agent.php'); // Assume this is the right place...
define ('PLESK_ADMIN_USER',        getenv("SETTINGS_admin_login"));
define ('PLESK_ADMIN_PASS',        getenv("SETTINGS_admin_password"));
define ('CF_API_SALT',             PLESK_ADMIN_USER . '9-y743fasd843983h498aasedfdf988aaq098dasf0932u023409pj' . PLESK_ADMIN_PASS);

include_once(getenv("WEB___DIR")."/cf-admin/apikey.php");

// This will contain the subscription data, if a subscription has occurred.
if(file_exists(getenv("WEB___DIR")."/cf-admin/cflicense.php")) {
    include_once(getenv("WEB___DIR")."/cf-admin/cflicense.php");
}

$xc = new xorCrypt();
$xc->set_key(CF_API_SALT);
$host_api_key = $xc->decrypt(CF_HOST_KEY);

$psa_key = defined("CF_PSA_KEY") ? CF_PSA_KEY : null;
$cf_sub_id = defined("CF_SUB_ID") ? CF_SUB_ID : null;
$cf_plan_tag = defined("CF_PLAN_TAG") ? CF_PLAN_TAG : null;

$new_psa_key = trim(file_get_contents(getenv("LICENSE_main_FILE")));
if ($new_psa_key!="") {
    if (($psa_key == null) || ($new_psa_key != $psa_key)) {
        $res = user_lookup(getenv("SETTINGS_cf_email"), $host_api_key);
        if ($res["response"]["user_key"] != null) {
            // Subscribe the zone to the corresponding reseller plan on CloudFlare.
            $zonesub_res = processZoneSub(getenv("BASE_URL_HOST"), $host_api_key, $res["response"]["user_key"], $new_psa_key);
        } else {
            return array("error" => TRUE, "msg"=> "Failed to look up user related to this subscription.");
        }

        // Assumption that this will actually work
        if ($zonesub_res["result"] == "success") {
            $psa_key = $new_psa_key;
            $cf_sub_id = $zonesub_res["response"]["sub_id"];
            $cf_plan_tag = $zonesub_res["request"]["plan_tag"];
        } else {
            return array("error" => TRUE, "msg"=> "Failed to apply subscription for this user.");
        }
    }
}

$f = @fopen(getenv("WEB___DIR")."/cf-admin/cflicense.php", "w");
if ($f) {
	fputs($f, "<?php\n");
	fputs($f, "define('CF_CUSTOMER_DOMAIN_KEY',              '" . CF_HOST_KEY ."');\n");

    // If there's a license subscription key set, lets make sure we are saving all the related information to the subscription.
    if ($psa_key) {
        fputs($f, "define('CF_PSA_KEY',     '" . $psa_key ."');\n");
        fputs($f, "define('CF_SUB_ID',      '" . $cf_sub_id ."');\n");
        fputs($f, "define('CF_PLAN_TAG',    '" . $cf_plan_tag ."');\n");
    }

    fputs($f, "?>\n");
	fclose($f);
} else {
	$errors[] = "Cannot write license file. Please check file privileges for: ".getenv("WEB___DIR");
	return FALSE;
}

?>
