<?php 

$params["site_server_path"] = getenv("WEB___DIR");
define("CF_HOST_KEY",	getenv("SETTINGS_host_key"));

$f = @fopen($params["site_server_path"]."/cf-admin/cflicense.php", "w");
if ($f) {
	fputs($f, "<?php\n");
	fputs($f, "define('CF_CUSTOMER_DOMAIN_KEY',              '" . CF_HOST_KEY ."');\n");
	fputs($f, "?>\n");
	fclose($f);
} else {
	$errors[] = "Cannot write license file. Please check file privileges for: ".$params["site_server_path"];
	return FALSE;
}

?>